
	 
	 <a href="mainpage.php"> <div class="border" id="menuMainItem"> <p> Меню </p> </div> </a>
	 <!-- <li class="border" id="menuMainItem">  Меню   </li>  -->
	<!-- <a href="index.php"> <li class="border" id="menuMainItem">  Меню   </li> </a>   -->
	<br>
	

