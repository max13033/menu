	<a href="index.php"> <li class="border">  Заказы   </li> </a>
	<a href="cats.php"> <li class="border">  Категории   </li> </a>
	<a href="subcats.php"> <li class="border">  Подкатегории   </li> </a>
	<a href="products.php"> <li class="border">  Продукты   </li> </a>

	<br/><br/><br/><br/>
	
	<a href="archive.php"> <li class="border">  Архив заказов  </li> </a>
