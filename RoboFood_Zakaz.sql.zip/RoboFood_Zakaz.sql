-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 20, 2015 at 08:03 PM
-- Server version: 5.1.40
-- PHP Version: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `RoboFood_Zakaz`
--

-- --------------------------------------------------------

--
-- Table structure for table `zakaz`
--

CREATE TABLE IF NOT EXISTS `zakaz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `robot` int(11) NOT NULL,
  `totalSum` decimal(6,0) NOT NULL,
  `timeStart` datetime NOT NULL,
  `timeEnd` datetime NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'started',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `zakaz`
--

INSERT INTO `zakaz` (`id`, `robot`, `totalSum`, `timeStart`, `timeEnd`, `status`) VALUES
(14, 3, 20000, '2015-05-20 19:05:58', '0000-00-00 00:00:00', 'completed'),
(13, 3, 11000, '2015-05-20 19:05:32', '0000-00-00 00:00:00', 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `zakazProducts`
--

CREATE TABLE IF NOT EXISTS `zakazProducts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zakaz` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `yield` decimal(10,0) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `zakazProducts`
--

INSERT INTO `zakazProducts` (`id`, `zakaz`, `title`, `yield`, `price`, `count`) VALUES
(1, 8, 'Бон Аква газ., и н/газ', 0, 0, 1),
(2, 8, 'Нарзан газ.', 0, 0, 4),
(17, 14, 'Ежевика', 100, 5000, 4),
(16, 13, 'Водка', 1000, 1000, 1),
(15, 13, 'Ежевика', 100, 5000, 2),
(14, 13, 'Огурцы', 0, 0, 1),
(7, 0, 'Бон Аква газ., и н/газ', 0, 0, 1),
(8, 0, 'Нарзан газ.', 0, 0, 1),
(9, 0, 'Водка', 0, 0, 2);
