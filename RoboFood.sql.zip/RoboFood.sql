-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 20, 2015 at 08:02 PM
-- Server version: 5.1.40
-- PHP Version: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `RoboFood`
--

-- --------------------------------------------------------

--
-- Table structure for table `cat`
--

CREATE TABLE IF NOT EXISTS `cat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` int(11) NOT NULL,
  `img` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `cat`
--

INSERT INTO `cat` (`id`, `position`, `img`, `title`, `desc`) VALUES
(1, 0, 'img/photoEuro.jpg', 'Европейская кухня', ''),
(2, 0, 'img/photoEast.jpg', 'Восточная кухня', ''),
(3, 0, 'img/photoChild.jpg', 'Детское меню', ''),
(4, 0, 'img/photoDrinks.jpg', 'Вода, вино, напитки', '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` int(11) NOT NULL,
  `subcat` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `desc` text NOT NULL,
  `yield` varchar(100) NOT NULL,
  `price` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `position`, `subcat`, `title`, `desc`, `yield`, `price`) VALUES
(1, 0, 1, 'Ассорти мясное', '(язык говяжий, ветчина, бастурма, бекон с/к)', '(400/90 гр)', 580),
(2, 0, 2, 'Овощной салат с сыром "Фета"', '(помидоры, огурцы, пекинская капуста, маслины, сладкий перец, сыр "Фета"', '280', 210),
(3, 0, 3, 'Салат из запечённых овощей', '(баклажан, помидор, перец сладкий)', '250', 260),
(4, 0, 4, 'Жюльен грибной', '', '200', 220),
(5, 0, 5, 'Ароматный куриный бульон с домашней пастой', '', '250', 160);

-- --------------------------------------------------------

--
-- Table structure for table `subcat`
--

CREATE TABLE IF NOT EXISTS `subcat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` int(11) NOT NULL,
  `cat` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `subcat`
--

INSERT INTO `subcat` (`id`, `position`, `cat`, `title`, `desc`) VALUES
(1, 0, 1, 'Холодные закуски', ''),
(2, 0, 1, 'Салаты', ''),
(3, 0, 1, 'Горячие салаты', ''),
(4, 0, 1, 'Горячие закуски', ''),
(5, 0, 1, 'Первые блюда', ''),
(6, 0, 1, 'Вторые блюда', ''),
(7, 0, 1, 'Паста', ''),
(8, 0, 1, 'Блюда на мангале', ''),
(9, 0, 1, 'Соусы', ''),
(10, 0, 1, 'Пицца', ''),
(11, 0, 1, 'Кальцоне', ''),
(12, 0, 1, 'Десерты', ''),
(13, 0, 1, 'Мороженное пломбир', ''),
(14, 0, 1, 'Мороженное пломбир', '');
